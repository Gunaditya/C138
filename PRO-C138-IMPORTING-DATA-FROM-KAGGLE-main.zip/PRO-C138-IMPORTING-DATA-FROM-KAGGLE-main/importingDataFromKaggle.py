import pandas as pd
import numpy as np
df1 = pd.read_csv('sharedArticles.csv')
df2 = pd.read_csv('usersInteractions.csv')
print(df1.head())
print(df2.head())